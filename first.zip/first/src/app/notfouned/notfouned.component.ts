import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-notfouned',
  templateUrl: './notfouned.component.html',
  styleUrls: ['./notfouned.component.css']
})
export class NotfounedComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
