import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
@Injectable({
  providedIn: 'root'
})
export class ProductService {
apiurl="http://localhost:3000/products"
  constructor(private http:HttpClient){

  }
  getallproducts():any{
    return this.http.get(this.apiurl)
  }
  
  
  
}


