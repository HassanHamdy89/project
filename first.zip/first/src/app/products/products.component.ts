import { Component, OnInit } from '@angular/core';
import{ProductService} from'../product.service';
@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})
export class ProductsComponent implements OnInit {
 

constructor(private product :ProductService){}

  ngOnInit(): void {
  this.getproducts();
  }
  prods=[];
  getproducts():void{
    this.product.getallproducts().subscribe((data:any)=>{
      this.prods=data;
      console.log(this.prods)
      
    })
  }
   

}
