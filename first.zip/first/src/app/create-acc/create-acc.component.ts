import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-create-acc',
  templateUrl: './create-acc.component.html',
  styleUrls: ['./create-acc.component.css']
})
export class CreateAccComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
